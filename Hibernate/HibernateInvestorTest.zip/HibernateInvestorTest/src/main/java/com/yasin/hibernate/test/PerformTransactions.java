package com.yasin.hibernate.test;

import java.util.Date;

public class PerformTransactions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InvestorTransaction it = new InvestorTransaction();
		
		Investor i = new Investor(102,"hagin", "bodi", 150000);
		System.out.println("investor staus -> " + it.addInvestor(i));
		
		Transaction t1 = new Transaction(2,new Date(2023,12,31),5000,103);
		System.out.println(" transaction status -> " + it.addTransaction(t1));
		

	}

}
